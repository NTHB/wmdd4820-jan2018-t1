// complex data structure
"Jacob";
let name = "Jacob";
let person = ["Jacob", "Tran"];
let students = [ people ];

// two dimensional array
// [ [] ] // an array that contains arrays

// ["Jacob", 12, true];
// ["Jacob", 12, true, [] ]
let person1 = ["Jacob", "Tran"];
let person2 = ["Denis", "Billette"];
let person3 = ["Jason", "Madar"];

let teachers = ["Jacob", "Denis", "Jason"];

let teachers = [
  person1,
  person2,
  person3
];

let teachers = [
  ["Jacob", "Tran"],     // 0
  ["Denis", "Billette"], // 1
  ["Jason", "Madar"]     // 2
];

teachers[1][1];

teachers[1]; // ["Denis", "Billette"]
person2[0]; // "Denis"
person2[1]; // "Billette"

teachers[1][1]; // "Billette"


// _|_|_
// _|_|_
//  | |
// TicTacToe
let tictactoe = [
  [O, null, O], // 0

  // 0 ,  1   , 2
  [null, X, null], // 1


  [null, null, X]  // 2
];

// place an "X" in the centre of this game board
tictactoe[1][1] = "X";
tictactoe[0][2] = "O";
tictactoe[2][2] = "X";
tictactoe[0][0] = "O";

// 3 dimensional structure
[ [ [] ] ]
// 4 dimensional structure
[ [ [ [] ] ] ]

// in a one dimensional array, you only need one address to get to the data






//
