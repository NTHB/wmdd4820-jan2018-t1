// functions - a set of instructions reference by name
// Tuesday
console.log("shower");
console.log("attend the morning class");
console.log("have lunch");
console.log("attend the afternoon class");
console.log("teach the robotics class");
console.log("dinner");
console.log("sleep");

// Wednesday
console.log("shower");
console.log("attend the morning class");
console.log("have lunch");
console.log("attend the afternoon class");
console.log("teach the robotics class");
console.log("dinner");
console.log("sleep");

// Thursday
console.log("shower");
console.log("attend the morning class");
console.log("have lunch");
console.log("attend the afternoon class");
console.log("teach the robotics class");
console.log("dinner");
console.log("sleep");

// Friday
console.log("shower");
console.log("attend the morning class");
console.log("have lunch");
console.log("attend the afternoon class");
console.log("teach the robotics class");
console.log("dinner");
console.log("sleep");

// code block
// defining a function
function routine() {
  console.log("shower");
  console.log("attend the morning class");
  console.log("have lunch");
  console.log("attend the afternoon class");
  console.log("teach the robotics class");
  console.log("dinner");
  console.log("sleep");
}

// execute a function
// use the function's name and add on: ();
// tu
routine();
// we
routine();
// th
routine();
// fr
routine();

function week() {
  routine();
  routine();
  routine();
  routine();
  routine();
}

week();

// commenting
// TODO: add calls to the amazon server
for (let i=0; i<5; i++) {
  routine();
}

//  2 ways to create functions

// declaritive function
// the function goes into the global namespace
function name() {}

// expressive function
// we can control where this function lives
let name = function() {};











//


//
