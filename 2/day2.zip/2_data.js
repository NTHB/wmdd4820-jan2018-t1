// data, data, data
// Google
// Amazon
// Facebook
// Wikipedia
// CIA, NSA

// Data Types
// numbers
// strings
// booleans

// numbers
// integer, double, float, long, decimal, short, .....
// Date(); Time(); character
// user defined data types
// array & objects

// array - list or collection of data
let name = "Jacob";
let age = 39;

// array
let names = ["Jacob", "Tran"];

let names = new Array(); // array constructor
let names = ["Dennis", "Jason", "Jacob"]; // array initializer

let shoppingCart = [
  "USB Key",
  "Dog Toys",
  "iPhone Charger"
];

// add items to my shoppingCart
// push is an array function, array method
// adds an item to end of my array
shoppingCart.push("Google Chromecast");

// remove an item from the start of my list
// pop, removes the last one!!!
shoppingCart.pop(); // will remove an item from the end of the list
shoppingCart.shift(); // will remove an item from the start of the list
shoppingCart.sort();

// arrays
// 0: "USB Key",
// 1: "Dog Toys",
// 2: "iPhone Charger"

shoppingCart[1]; // "Dog Toys"
shoppingCart[0]; // "USB Key"
shoppingCart[2]; // "iPhone Charger"
shoppingCart[20]; // ???

let shoppingCart = [
  "USB Key",
  "Dog Toys",
  "IPhone Charger"
];

// shoppingCart[1]; // "Dog Toys"
// shoppingCart[0]; // "USB Key"
// shoppingCart[2]; // "iPhone Charger"
shoppingCart[20] = "Nintendo Switch"; // ???

// dynamicall sized arrays
console.log( shoppingCart );

// is there a method/function that will remove my empty slots?

// look through the documentation and let me know
// shoppingCart.squeeze();









//






//








//
