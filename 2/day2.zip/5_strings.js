// Strings
"Jacob";
"J";
"a";
"c";
"o";
"b";

//
let name = "Jacob"; // string

let name = ["Jacob"]; // array that contains a string

let name = ["J", "a", "c", "o", "b"]; // array of characters

// strings and arrays are very closely related
let name = "Jacob";
// typeof(name);
name[0]; // strings can access
name[4];
name[name.length-1];

console.log(name);
name[0] = "Y"; // cannot be mutated
console.log(name);
name = "Yacob";
console.log(name);

// array methods/functions
// string methods/functions
let name = "Jacob";
name.split();

let name = "Jacob";
let characters = name.split("");
characters[0] = "Y";
console.log( characters );
name = characters.join("");







//










//
