// good afternoon everyone!
// javascript
// ECMAScript 6
// calculator
5 + 5;
// math natively support in js
Math.random(); // between 0 and 1
Math.round();
Math.PI;

// remember
// variables
let result = 5 + 5;
// var;
// const;
result * 2 + 3 - 7 ** 2;

// simple data
let name = "Jacob";
let age = 39;

// data structures
// array
let names = ["Jacob", "Thung", "Tran"];
let lotto = [12,23,34,39,45,49];

// dynamically sized, mixed typed
let account = ["Jacob", 39, 20934.23, true];

// shoppingCart       0          1                2
let shoppingCart = ["Pens", "iPhone Cover", "USB-C Cable"];

// array - indexed list of information
shoppingCart[0];
shoppingCart[1];
shoppingCart[2];
shoppingCart[3]; // undefined
// arrays are zero-based
shoppingCart[4] = "Water Bottle";

// stack overflow



















//
