// complex data

// simple data
let name = "Jacob";

// complex
let names = ["Jacob", "Tran"];

// complexity + 1
// 2 dimensional array
let teachers = [
  ["Jacob", "Tran"],
  ["Kevin", "McMillian"],
  ["Jessica", "Ortega"]
];

// 2 axis', require 2 pieces of information to retrieve our data
names[0]; // i can get my first name
names[1]; // i can get my last name

teachers[0]; // an array: ["Jacob", "Tran"]
teachers[0][0]; // "Jacob"
teachers[0][1]; // "Tran"

// last names
teachers[0][1];
teachers[1][1];
teachers[2][1];

teachers[row][col];
// spreadsheet, bingo, tictactoe, battleship
// B3 put a formula that calculates the total
// put an "x" in the middle square of the 3x3 grid
// Shoot H4, "You sunk my battleship!"''

// databases - tables, rows, columns, data, SQL
// persistance - to persist, to last, to exist

// table of teachers???
// id | first name | last name | age | <- fields
//  0    Jacob        Tran        39  <- record
//  1    Kevin        McMillian   21
//
// [
//   [0, "Jacob","Tran", 39],
//   [1, "Kevin", "McMillian", 21]
// ]

// 3 dimensional array
// [[[]]]
// 3 pieces of information
    _
  _|_|_
 |_|_|_|
   |_|
   |_|

   _ _ _
  |_|_|_|
  |_|_|_|
  |_|_|_|

let red = [null, null, null, null, null, null, null, null, null];

let red = [
  [null, null, null],
  [null, null, null],
  [null, null, null]
];

let rubixCube = [red, "blue", "green", "yellow", "white", "orange"];


let rubixCube = [
  [
    [null, null, null],
    [null, null, null],
    [null, null, null]
  ]
];

rubixCube[face][row][col];

// [school][teacher][first name]






 //
