// boolean - 2 states
// true or false
5 > 4;
// >, <, >=, <=, !=, ==, ===
