// hi everyone!

5 + 5; // terminate a line of code ;

// comment
// It was the best of times.

10 * 2;
234 - 2;
6 / 3;

// % ??? -> REMAINDER
10 % 3; // R1
9 % 3; // 0
// MODULO

2 ** 8;
Math.PI;
Math.random(); // between 0 and 1

9 % 3;
2 ** 8;

Math.PI;
Math.random();

console.log(9 % 3);
console.log(2 ** 3);
console.log(Math.random());
