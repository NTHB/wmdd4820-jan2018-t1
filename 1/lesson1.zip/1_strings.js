// text, strings
// J-a-c-o-b
"";
'';
``;

"Hello";
'Goodbye';
`How are ya?`;

"Jacob's Computer";
'"Hello", said Jacob';
'Hello\'s';

``; // backtick string, above the tab key on the keyboard

"a" + "b"; // math? or text?
`${"a"} ${"b"}`; // string interpolation


`${ /* expression */ } ${"b"}`;
`There are ${ 6 + 6 } eggs in a dozen.`;







//
