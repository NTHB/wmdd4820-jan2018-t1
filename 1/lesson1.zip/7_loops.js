let counter = 0;

while(true) {
  console.log("WMDD!!");
  counter++;

  if (counter > 3) {
    break; // parachute
  }
}

Mat
