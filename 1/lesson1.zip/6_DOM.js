// document - what your user sees

// console - developers tool

// window - application
