// bill gates
// logic gating
// variables, text, numbers, gates
let age = 39;

if (age > 18) {
  console.log("at langara");
} else {
  console.log("elementary school");
}

5 + 5;
10 * 2;

//
if (5 > 6) {
  console.log("Inside!");
}

// variables, text, numbers, gates
let age = 39;

if (age > 18) {
  console.log("at langara");
} else {
  console.log("elementary school");
}

// more categories
if (age > 18) {
  console.log("langara");
} else if (age > 13) {
  console.log("highschool");
} else {
  console.log("elementary school");
}

// even more categories
if (age > 18) {
  console.log("langara");
} else if (age > 13) {
  console.log("highschool");
} else if (age > 5) {
  console.log("elementary school");
} else {
  console.log("preschool");
}

// ternary operator
if (age > 18) {
  console.log("at langara");
} else {
  console.log("elementary school");
}

(age > 18) ? console.log("at langara") : console.log("elementary school");

// switch case
switch(age) {
  case 39:
    console.log("Old");
    break;
  case 18:
    console.log("Young");
    break;
  default:
    console.log("Other");
}

//
