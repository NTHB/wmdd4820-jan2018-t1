// variables
// variable - it stores information in memory

5 + 5;

10 * 2;

20 / 4;

let age = 39;
age * 2;

let age2 = 20;

var name = "Jacob";
var name = "Denis";
// var is deprecated, meaning that it is an older implementation of the language

// constant
const PI = 3.14159;
PI = 42;





//var
//const
