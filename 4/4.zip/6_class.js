// class - classification
// class describes an object
class Cookie {}

const chocolateChip = {};
const chocolateChip = new Cookie();
const oatmeal = new Cookie();
const oreo = new Cookie();

class House {} // blueprint
const home = new House();
const townhome = new House();
const duplex = new House();
const condo = new House();
const tinyHome = new House();

const chocolateChip = {
  name:
  sugar:
  flour:
  glutten:
  print()
  eat()
  bake()
};
const oatmeal = {
  name:
  sugar:
  flour:
  glutten:
  print()
  eat()
  bake()
};
const oreo = {
  name:
  sugar:
  flour:
  glutten:
  print()
  eat()
  bake()
};
